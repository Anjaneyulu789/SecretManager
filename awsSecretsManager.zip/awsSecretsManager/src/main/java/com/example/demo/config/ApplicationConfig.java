package com.example.demo.config;
import com.google.gson.Gson;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueResponse;
import software.amazon.awssdk.services.secretsmanager.model.SecretsManagerException;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class ApplicationConfig {
    private Gson gson = new Gson();

    @Bean
    DataSource dataSource() {
        AwsSecrets secrets = getSecret();

        return DataSourceBuilder.create()
                  .username(secrets.getUsername())
                  .password(secrets.getPassword())
                  .url(secrets.getUrl())
                  //.url("jdbc:mysql://b2b.c30gaacy48oz.ap-south-1.rds.amazonaws.com:3306/b2bdev?createDatabaseIfNotExist=true&useUnicode=true")
                  .driverClassName("com.mysql.cj.jdbc.Driver")
                  .build();
    }

    private AwsSecrets getSecret() {
//change StringName
        String secretName = "arn:aws:secretsmanager:us-east-1:891377328519:secret:MyDatabaseSecret02-TobIId";
        Region region = Region.of("us-east-1");   ///change Region
        
        // Set your AWS access key and secret key directly
        AwsBasicCredentials awsCreds = AwsBasicCredentials.create("", "");

        SecretsManagerClient secretsClient = SecretsManagerClient.builder()
                .region(region)
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();

        try {
            GetSecretValueRequest valueRequest = GetSecretValueRequest.builder().secretId(secretName).build();

            GetSecretValueResponse valueResponse = secretsClient.getSecretValue(valueRequest);
            String secret = valueResponse.secretString();
            System.out.println("Secret value is: " + secret);
            return gson.fromJson(secret, AwsSecrets.class);

        } catch (SecretsManagerException e) {
            secretsClient.close();
            System.err.println(e.awsErrorDetails().errorMessage());
            System.exit(1);
        }
        return null;
    }
}
